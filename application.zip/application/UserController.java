package application;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class UserController {
	
	@FXML
	private Button BookButton;
	@FXML
	private Button ViewButton;
	@FXML
	private TextArea CustomerFlights;
	
	public void ViewFlights(ActionEvent event) throws Exception {
		Connection connection = null;
		
		try {
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/finalProject", "root", "AspenBoots22");
		} catch (Exception e) {
			e.printStackTrace();
		}
		PreparedStatement p = null;
	    ResultSet rs = null;

	    String sql = "SELECT * FROM user_flights";
	    p = connection.prepareStatement(sql);
	    rs = p.executeQuery();
	    StringBuilder display = new StringBuilder("Your Current Flights:     ");
	    while(rs.next()) {
	    	int flight_id = rs.getInt("flight_id");
	    	String date = rs.getString("date");
	    	String destination = rs.getString("destination");
	    	display.append(flight_id + " " + date + " " + destination + " : ");
	    }
	    CustomerFlights.setText(display.toString());
	}

	public void BookFlight(ActionEvent event) throws Exception {
		Stage primaryStage = new Stage();
		Parent root = FXMLLoader.load(getClass().getResource("/application/BookFlight.fxml"));
		Scene scene = new Scene(root, 700, 500);
		scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
		primaryStage.setScene(scene);
		primaryStage.show();
	}
}
